<li class="nav-header">DATA PLATFORM</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_platform_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_platform_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Platform
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_platform_pjm_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah Penjamin
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_platform_pjm_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Penjamin
        </p>
    </a>
</li>