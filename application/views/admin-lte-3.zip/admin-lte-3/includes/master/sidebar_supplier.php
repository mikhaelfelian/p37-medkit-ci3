<li class="nav-header">DATA SUPPLIER</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_supplier_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_supplier_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Supplier List
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_supplier_import.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-upload"></i>
        <p>
            Import Data
        </p>
    </a>
</li>