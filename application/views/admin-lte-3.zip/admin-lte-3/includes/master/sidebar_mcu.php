<li class="nav-header">DATA MEDICAL CHECKUP</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_kat_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah Kategori
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah Pemeriksaan
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_perusahaan_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah Rekanan
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_kat_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Kategori
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Pemeriksaan
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_header_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Tipe Pemeriksaan <br/>
            <small><i>(Audiometri, Spirometri, dll)</i></small>
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_mcu_perusahaan_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Perusahaan
        </p>
    </a>
</li>