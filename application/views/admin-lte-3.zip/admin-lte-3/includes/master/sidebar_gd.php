<li class="nav-header">DATA GUDANG</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_barang_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_gudang_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Data Gudang List
        </p>
    </a>
</li>