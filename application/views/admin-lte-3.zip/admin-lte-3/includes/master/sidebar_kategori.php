<li class="nav-header">DATA KATEGORI</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_kategori_tambah.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-plus"></i>
        <p>
            Tambah
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('master/data_kategori_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Kategori
        </p>
    </a>
</li>