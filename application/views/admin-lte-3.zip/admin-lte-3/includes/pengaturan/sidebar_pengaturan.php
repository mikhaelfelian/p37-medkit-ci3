<li class="nav-header">PENGATURAN</li>
<li class="nav-item">
    <a href="<?php echo base_url('pengaturan/data_user_list.php') ?>" class="nav-link">
        <i class="nav-icon fa fa-users"></i>
        <p>Pengguna</p>
    </a>
</li>
<!--<li class="nav-item">
    <a href="<?php // echo base_url('pengaturan/backups.php') ?>" class="nav-link">
        <i class="nav-icon fa fa-file-download"></i>
        <p>Backup</p>
    </a>
</li>-->