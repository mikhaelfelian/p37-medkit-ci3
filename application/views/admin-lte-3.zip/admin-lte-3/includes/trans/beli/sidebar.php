<li class="nav-header">APOTIK</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/trans_beli.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-shopping-cart"></i>
        <p>
            POS
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/data_po_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Penjualan
        </p>
    </a>
</li>
<li class="nav-header">PEMBELIAN</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/trans_beli.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-shopping-cart"></i>
        <p>
            Trans Beli
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/data_po_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-shopping-basket"></i>
        <p>
            Trans RFQ
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/data_po_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-list"></i>
        <p>
            Data RFQ
        </p>
    </a>
</li>