<li class="nav-header">REQUEST FOR QUOTATION</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/trans_beli_po.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-shopping-cart"></i>
        <p>
            Input RFQ
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo base_url('transaksi/pembelian/data_po_list.php') ?>" class="nav-link">
        <i class="nav-icon fas fa-shopping-basket"></i>
        <p>
            Data RFQ
        </p>
    </a>
</li>