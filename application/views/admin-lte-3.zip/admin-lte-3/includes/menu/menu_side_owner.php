<li class="nav-header">EXAMPLES</li>
<li class="nav-item">
    <a href="pages/gallery.html" class="nav-link">
        <i class="nav-icon far fa-image"></i>
        <p>
            Gallery
        </p>
    </a>
</li>