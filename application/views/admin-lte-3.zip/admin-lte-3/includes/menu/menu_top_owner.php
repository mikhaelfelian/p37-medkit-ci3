<li class="nav-item d-none d-sm-inline-block">
    <a href="<?php echo base_url('master/index.php') ?>" class="nav-link">Master</a>
</li>
<li class="nav-item d-none d-sm-inline-block">
    <a href="#" class="nav-link">Gudang</a>
</li>
<li class="nav-item d-none d-sm-inline-block">
    <a href="<?php echo base_url('medcheck/index.php') ?>" class="nav-link">Medical Check</a>
</li>
<li class="nav-item d-none d-sm-inline-block">
    <a href="<?php echo base_url('dashboard.php') ?>" class="nav-link">Transaksi</a>
</li>
<li class="nav-item d-none d-sm-inline-block">
    <a href="<?php echo base_url('dashboard.php') ?>" class="nav-link">Laporan</a>
</li>