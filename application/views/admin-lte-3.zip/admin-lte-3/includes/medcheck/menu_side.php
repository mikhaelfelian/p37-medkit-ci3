<li class="nav-header">MEDICAL CHECK</li>
<li class="nav-item">
    <a href="<?php echo base_url('medcheck/tambah') ?>" class="nav-link">
        <i class="nav-icon fa fa-plus"></i>
        <p>Tambah Checkup</p>
    </a>
</li>