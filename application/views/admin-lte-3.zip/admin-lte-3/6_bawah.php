
        <!-- OPTIONAL SCRIPTS -->
        <!--<script src="<?php echo base_url('assets/theme/admin-lte-3/plugins/chart.js/Chart.min.js'); ?>"></script>-->
        <!-- AdminLTE for demo purposes -->
        <!--<script src="<?php // echo base_url('assets/theme/admin-lte-3/dist/js/demo.js'); ?>"></script>-->
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <!--<script src="<?php // echo base_url('assets/theme/admin-lte-3/dist/js/pages/dashboard3.js'); ?>"></script>-->
    </body>
</html>